# Changelog

En cas d'absence de note dans ce chapitre, les mises à jour ne concernent que la doc, les traductions et des corrections mineures

## Janvier 2017

Mise en place du retain en option des commandes actions

MQTT est à nouveau entièrement en mode automatisé avec découverte des topics publiés sur le Mosquitto cible

## Octobre 2017

Prise en compte de Stretch et PHP7 en natif dans les dépendances
