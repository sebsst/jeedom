# Änderungsprotokoll

Wenn in diesem Kapitel keine Erläuterungen vorhanden sind, wurden Aktualisierungen nur für die Dokumente, Übersetzungen und kleinere Korrekturen vorgenommen

## Januar 2017

Mise en place du retain en option des commandes actions

MQTT ist wieder vollständig im automatischen Modus mit der Entdeckung von Themen, die auf dem Ziel-Mosquitto veröffentlicht wurden

## Oktober 2017

Berücksichtigung von Stretch und PHP7 nativ in Abhängigkeiten
